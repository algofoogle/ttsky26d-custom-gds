module tt_um_algofoogle_hello_world (clk,
    ena,
    k0,
    k1,
    k2,
    k3,
    k4,
    rst_n,
    ui_in,
    uio_in,
    uio_oe,
    uio_out,
    uo_out);
 input clk;
 input ena;
 output k0;
 output k1;
 output k2;
 output k3;
 output k4;
 input rst_n;
 input [7:0] ui_in;
 input [7:0] uio_in;
 output [7:0] uio_oe;
 output [7:0] uio_out;
 output [7:0] uo_out;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire \counter[10] ;
 wire \counter[11] ;
 wire \counter[12] ;
 wire \counter[13] ;
 wire \counter[14] ;
 wire \counter[15] ;
 wire \counter[5] ;
 wire \counter[6] ;
 wire \counter[7] ;
 wire \counter[8] ;
 wire \counter[9] ;
 wire inverted;

 sky130_fd_sc_hd__inv_1 _086_ (.A(k3),
    .Y(_056_));
 sky130_fd_sc_hd__nand2_1 _087_ (.A(k0),
    .B(ui_in[0]),
    .Y(_057_));
 sky130_fd_sc_hd__nor2_1 _088_ (.A(k1),
    .B(ui_in[1]),
    .Y(_058_));
 sky130_fd_sc_hd__nand2_1 _089_ (.A(k1),
    .B(ui_in[1]),
    .Y(_059_));
 sky130_fd_sc_hd__nor2b_1 _090_ (.A(_058_),
    .B_N(_059_),
    .Y(_060_));
 sky130_fd_sc_hd__xnor2_1 _091_ (.A(_057_),
    .B(_060_),
    .Y(uo_out[1]));
 sky130_fd_sc_hd__o21ai_0 _092_ (.A1(_057_),
    .A2(_058_),
    .B1(_059_),
    .Y(_061_));
 sky130_fd_sc_hd__xnor2_1 _093_ (.A(k2),
    .B(ui_in[2]),
    .Y(_062_));
 sky130_fd_sc_hd__xnor2_1 _094_ (.A(_061_),
    .B(_062_),
    .Y(uo_out[2]));
 sky130_fd_sc_hd__maj3_1 _095_ (.A(k2),
    .B(ui_in[2]),
    .C(_061_),
    .X(_063_));
 sky130_fd_sc_hd__xnor2_1 _096_ (.A(k3),
    .B(ui_in[3]),
    .Y(_064_));
 sky130_fd_sc_hd__xnor2_1 _097_ (.A(_063_),
    .B(_064_),
    .Y(uo_out[3]));
 sky130_fd_sc_hd__maj3_1 _098_ (.A(k3),
    .B(ui_in[3]),
    .C(_063_),
    .X(_065_));
 sky130_fd_sc_hd__xnor2_1 _099_ (.A(k4),
    .B(ui_in[4]),
    .Y(_066_));
 sky130_fd_sc_hd__xnor2_1 _100_ (.A(_065_),
    .B(_066_),
    .Y(uo_out[4]));
 sky130_fd_sc_hd__maj3_1 _101_ (.A(k4),
    .B(ui_in[4]),
    .C(_065_),
    .X(_067_));
 sky130_fd_sc_hd__xnor2_1 _102_ (.A(\counter[5] ),
    .B(ui_in[5]),
    .Y(_068_));
 sky130_fd_sc_hd__xnor2_1 _103_ (.A(_067_),
    .B(_068_),
    .Y(uo_out[5]));
 sky130_fd_sc_hd__maj3_1 _104_ (.A(\counter[5] ),
    .B(ui_in[5]),
    .C(_067_),
    .X(_069_));
 sky130_fd_sc_hd__xnor2_1 _105_ (.A(\counter[6] ),
    .B(ui_in[6]),
    .Y(_070_));
 sky130_fd_sc_hd__xnor2_1 _106_ (.A(_069_),
    .B(_070_),
    .Y(uo_out[6]));
 sky130_fd_sc_hd__maj3_1 _107_ (.A(\counter[6] ),
    .B(ui_in[6]),
    .C(_069_),
    .X(_071_));
 sky130_fd_sc_hd__and2_0 _108_ (.A(\counter[7] ),
    .B(ui_in[7]),
    .X(_072_));
 sky130_fd_sc_hd__or2_0 _109_ (.A(\counter[7] ),
    .B(ui_in[7]),
    .X(_073_));
 sky130_fd_sc_hd__nand2b_1 _110_ (.A_N(_072_),
    .B(_073_),
    .Y(_074_));
 sky130_fd_sc_hd__xnor2_1 _111_ (.A(_071_),
    .B(_074_),
    .Y(uo_out[7]));
 sky130_fd_sc_hd__xnor2_1 _112_ (.A(\counter[8] ),
    .B(inverted),
    .Y(_075_));
 sky130_fd_sc_hd__inv_1 _113_ (.A(_075_),
    .Y(_076_));
 sky130_fd_sc_hd__o21a_1 _114_ (.A1(_071_),
    .A2(_072_),
    .B1(_073_),
    .X(_077_));
 sky130_fd_sc_hd__xnor2_1 _115_ (.A(_075_),
    .B(_077_),
    .Y(uio_out[0]));
 sky130_fd_sc_hd__xor2_1 _116_ (.A(inverted),
    .B(\counter[9] ),
    .X(_078_));
 sky130_fd_sc_hd__maj3_1 _117_ (.A(\counter[8] ),
    .B(inverted),
    .C(_077_),
    .X(_079_));
 sky130_fd_sc_hd__xor2_1 _118_ (.A(_078_),
    .B(_079_),
    .X(uio_out[1]));
 sky130_fd_sc_hd__xor2_1 _119_ (.A(inverted),
    .B(\counter[10] ),
    .X(_080_));
 sky130_fd_sc_hd__o2111ai_1 _120_ (.A1(_071_),
    .A2(_072_),
    .B1(_073_),
    .C1(_076_),
    .D1(_078_),
    .Y(_081_));
 sky130_fd_sc_hd__o21ai_0 _121_ (.A1(\counter[8] ),
    .A2(\counter[9] ),
    .B1(inverted),
    .Y(_082_));
 sky130_fd_sc_hd__nand2_1 _122_ (.A(_081_),
    .B(_082_),
    .Y(_083_));
 sky130_fd_sc_hd__xor2_1 _123_ (.A(_080_),
    .B(_083_),
    .X(uio_out[2]));
 sky130_fd_sc_hd__xor2_1 _124_ (.A(inverted),
    .B(\counter[11] ),
    .X(_084_));
 sky130_fd_sc_hd__maj3_1 _125_ (.A(inverted),
    .B(\counter[10] ),
    .C(_083_),
    .X(_085_));
 sky130_fd_sc_hd__xor2_1 _126_ (.A(_084_),
    .B(_085_),
    .X(uio_out[3]));
 sky130_fd_sc_hd__nand2_1 _127_ (.A(_080_),
    .B(_084_),
    .Y(_016_));
 sky130_fd_sc_hd__o21ai_0 _128_ (.A1(\counter[10] ),
    .A2(\counter[11] ),
    .B1(inverted),
    .Y(_017_));
 sky130_fd_sc_hd__o211a_1 _129_ (.A1(_081_),
    .A2(_016_),
    .B1(_017_),
    .C1(_082_),
    .X(_018_));
 sky130_fd_sc_hd__nor2_1 _130_ (.A(inverted),
    .B(\counter[12] ),
    .Y(_019_));
 sky130_fd_sc_hd__nand2_1 _131_ (.A(inverted),
    .B(\counter[12] ),
    .Y(_020_));
 sky130_fd_sc_hd__nor2b_1 _132_ (.A(_019_),
    .B_N(_020_),
    .Y(_021_));
 sky130_fd_sc_hd__xnor2_1 _133_ (.A(_018_),
    .B(_021_),
    .Y(uio_out[4]));
 sky130_fd_sc_hd__o21a_1 _134_ (.A1(_018_),
    .A2(_019_),
    .B1(_020_),
    .X(_022_));
 sky130_fd_sc_hd__nand2_1 _135_ (.A(inverted),
    .B(\counter[13] ),
    .Y(_023_));
 sky130_fd_sc_hd__nor2_1 _136_ (.A(inverted),
    .B(\counter[13] ),
    .Y(_024_));
 sky130_fd_sc_hd__xor2_1 _137_ (.A(inverted),
    .B(\counter[13] ),
    .X(_025_));
 sky130_fd_sc_hd__xnor2_1 _138_ (.A(_022_),
    .B(_025_),
    .Y(uio_out[5]));
 sky130_fd_sc_hd__o21ai_0 _139_ (.A1(_022_),
    .A2(_024_),
    .B1(_023_),
    .Y(_026_));
 sky130_fd_sc_hd__xnor2_1 _140_ (.A(inverted),
    .B(\counter[14] ),
    .Y(_027_));
 sky130_fd_sc_hd__xnor2_1 _141_ (.A(_026_),
    .B(_027_),
    .Y(uio_out[6]));
 sky130_fd_sc_hd__nor4bb_1 _142_ (.A(\counter[13] ),
    .B(\counter[14] ),
    .C_N(_022_),
    .D_N(inverted),
    .Y(_028_));
 sky130_fd_sc_hd__nor4b_1 _143_ (.A(inverted),
    .B(_022_),
    .C(_024_),
    .D_N(\counter[14] ),
    .Y(_029_));
 sky130_fd_sc_hd__nor2_1 _144_ (.A(_028_),
    .B(_029_),
    .Y(_030_));
 sky130_fd_sc_hd__xnor2_1 _145_ (.A(\counter[15] ),
    .B(_030_),
    .Y(uio_out[7]));
 sky130_fd_sc_hd__xor2_1 _146_ (.A(k0),
    .B(ui_in[0]),
    .X(uo_out[0]));
 sky130_fd_sc_hd__nand3_1 _147_ (.A(k0),
    .B(k1),
    .C(k2),
    .Y(_031_));
 sky130_fd_sc_hd__nor2_1 _148_ (.A(_056_),
    .B(_031_),
    .Y(_032_));
 sky130_fd_sc_hd__and3_1 _149_ (.A(k4),
    .B(\counter[5] ),
    .C(_032_),
    .X(_033_));
 sky130_fd_sc_hd__and3_1 _150_ (.A(\counter[6] ),
    .B(\counter[7] ),
    .C(_033_),
    .X(_034_));
 sky130_fd_sc_hd__and2_0 _151_ (.A(\counter[8] ),
    .B(_034_),
    .X(_035_));
 sky130_fd_sc_hd__and3_1 _152_ (.A(\counter[9] ),
    .B(\counter[10] ),
    .C(_035_),
    .X(_036_));
 sky130_fd_sc_hd__and2_0 _153_ (.A(\counter[11] ),
    .B(_036_),
    .X(_037_));
 sky130_fd_sc_hd__and3_1 _154_ (.A(\counter[12] ),
    .B(\counter[13] ),
    .C(_037_),
    .X(_038_));
 sky130_fd_sc_hd__and2_0 _155_ (.A(\counter[14] ),
    .B(_038_),
    .X(_039_));
 sky130_fd_sc_hd__o21ai_0 _156_ (.A1(\counter[14] ),
    .A2(_038_),
    .B1(rst_n),
    .Y(_040_));
 sky130_fd_sc_hd__nor2_1 _157_ (.A(_039_),
    .B(_040_),
    .Y(_000_));
 sky130_fd_sc_hd__o21ai_0 _158_ (.A1(\counter[15] ),
    .A2(_039_),
    .B1(rst_n),
    .Y(_041_));
 sky130_fd_sc_hd__a21oi_1 _159_ (.A1(\counter[15] ),
    .A2(_039_),
    .B1(_041_),
    .Y(_001_));
 sky130_fd_sc_hd__nor2b_1 _160_ (.A(k0),
    .B_N(rst_n),
    .Y(_002_));
 sky130_fd_sc_hd__o21ai_0 _161_ (.A1(k0),
    .A2(k1),
    .B1(rst_n),
    .Y(_042_));
 sky130_fd_sc_hd__a21oi_1 _162_ (.A1(k0),
    .A2(k1),
    .B1(_042_),
    .Y(_003_));
 sky130_fd_sc_hd__a21oi_1 _163_ (.A1(k0),
    .A2(k1),
    .B1(k2),
    .Y(_043_));
 sky130_fd_sc_hd__nand2_1 _164_ (.A(rst_n),
    .B(_031_),
    .Y(_044_));
 sky130_fd_sc_hd__nor2_1 _165_ (.A(_043_),
    .B(_044_),
    .Y(_004_));
 sky130_fd_sc_hd__a31oi_1 _166_ (.A1(k0),
    .A2(k1),
    .A3(k2),
    .B1(k3),
    .Y(_045_));
 sky130_fd_sc_hd__nor3b_1 _167_ (.A(_032_),
    .B(_045_),
    .C_N(rst_n),
    .Y(_005_));
 sky130_fd_sc_hd__o21ai_0 _168_ (.A1(k4),
    .A2(_032_),
    .B1(rst_n),
    .Y(_046_));
 sky130_fd_sc_hd__a21oi_1 _169_ (.A1(k4),
    .A2(_032_),
    .B1(_046_),
    .Y(_006_));
 sky130_fd_sc_hd__a21oi_1 _170_ (.A1(k4),
    .A2(_032_),
    .B1(\counter[5] ),
    .Y(_047_));
 sky130_fd_sc_hd__nor3b_1 _171_ (.A(_033_),
    .B(_047_),
    .C_N(rst_n),
    .Y(_007_));
 sky130_fd_sc_hd__o21ai_0 _172_ (.A1(\counter[6] ),
    .A2(_033_),
    .B1(rst_n),
    .Y(_048_));
 sky130_fd_sc_hd__a21oi_1 _173_ (.A1(\counter[6] ),
    .A2(_033_),
    .B1(_048_),
    .Y(_008_));
 sky130_fd_sc_hd__a21oi_1 _174_ (.A1(\counter[6] ),
    .A2(_033_),
    .B1(\counter[7] ),
    .Y(_049_));
 sky130_fd_sc_hd__nor3b_1 _175_ (.A(_034_),
    .B(_049_),
    .C_N(rst_n),
    .Y(_009_));
 sky130_fd_sc_hd__o21ai_0 _176_ (.A1(\counter[8] ),
    .A2(_034_),
    .B1(rst_n),
    .Y(_050_));
 sky130_fd_sc_hd__nor2_1 _177_ (.A(_035_),
    .B(_050_),
    .Y(_010_));
 sky130_fd_sc_hd__o21ai_0 _178_ (.A1(\counter[9] ),
    .A2(_035_),
    .B1(rst_n),
    .Y(_051_));
 sky130_fd_sc_hd__a21oi_1 _179_ (.A1(\counter[9] ),
    .A2(_035_),
    .B1(_051_),
    .Y(_011_));
 sky130_fd_sc_hd__a21oi_1 _180_ (.A1(\counter[9] ),
    .A2(_035_),
    .B1(\counter[10] ),
    .Y(_052_));
 sky130_fd_sc_hd__nor3b_1 _181_ (.A(_036_),
    .B(_052_),
    .C_N(rst_n),
    .Y(_012_));
 sky130_fd_sc_hd__o21ai_0 _182_ (.A1(\counter[11] ),
    .A2(_036_),
    .B1(rst_n),
    .Y(_053_));
 sky130_fd_sc_hd__nor2_1 _183_ (.A(_037_),
    .B(_053_),
    .Y(_013_));
 sky130_fd_sc_hd__o21ai_0 _184_ (.A1(\counter[12] ),
    .A2(_037_),
    .B1(rst_n),
    .Y(_054_));
 sky130_fd_sc_hd__a21oi_1 _185_ (.A1(\counter[12] ),
    .A2(_037_),
    .B1(_054_),
    .Y(_014_));
 sky130_fd_sc_hd__a21oi_1 _186_ (.A1(\counter[12] ),
    .A2(_037_),
    .B1(\counter[13] ),
    .Y(_055_));
 sky130_fd_sc_hd__nor3b_1 _187_ (.A(_038_),
    .B(_055_),
    .C_N(rst_n),
    .Y(_015_));
 sky130_fd_sc_hd__dfxtp_1 _188_ (.CLK(clk),
    .D(_008_),
    .Q(\counter[6] ));
 sky130_fd_sc_hd__dfxtp_1 _189_ (.CLK(clk),
    .D(_009_),
    .Q(\counter[7] ));
 sky130_fd_sc_hd__dfxtp_1 _190_ (.CLK(clk),
    .D(_010_),
    .Q(\counter[8] ));
 sky130_fd_sc_hd__dfxtp_1 _191_ (.CLK(clk),
    .D(_011_),
    .Q(\counter[9] ));
 sky130_fd_sc_hd__dfxtp_1 _192_ (.CLK(clk),
    .D(_012_),
    .Q(\counter[10] ));
 sky130_fd_sc_hd__dfxtp_1 _193_ (.CLK(clk),
    .D(_013_),
    .Q(\counter[11] ));
 sky130_fd_sc_hd__dfxtp_1 _194_ (.CLK(clk),
    .D(_014_),
    .Q(\counter[12] ));
 sky130_fd_sc_hd__dfxtp_1 _195_ (.CLK(clk),
    .D(_015_),
    .Q(\counter[13] ));
 sky130_fd_sc_hd__dfxtp_1 _196_ (.CLK(clk),
    .D(_000_),
    .Q(\counter[14] ));
 sky130_fd_sc_hd__dfxtp_1 _197_ (.CLK(clk),
    .D(_001_),
    .Q(\counter[15] ));
 sky130_fd_sc_hd__dfxtp_1 _198_ (.CLK(clk),
    .D(_002_),
    .Q(k0));
 sky130_fd_sc_hd__dfxtp_1 _199_ (.CLK(clk),
    .D(_003_),
    .Q(k1));
 sky130_fd_sc_hd__dfxtp_1 _200_ (.CLK(clk),
    .D(_004_),
    .Q(k2));
 sky130_fd_sc_hd__dfxtp_1 _201_ (.CLK(clk),
    .D(_005_),
    .Q(k3));
 sky130_fd_sc_hd__dfxtp_1 _202_ (.CLK(clk),
    .D(_006_),
    .Q(k4));
 sky130_fd_sc_hd__dfxtp_1 _203_ (.CLK(clk),
    .D(_007_),
    .Q(\counter[5] ));
 sky130_fd_sc_hd__conb_1 _204_ (.HI(uio_oe[0]));
 sky130_fd_sc_hd__conb_1 _205_ (.HI(uio_oe[1]));
 sky130_fd_sc_hd__conb_1 _206_ (.HI(uio_oe[2]));
 sky130_fd_sc_hd__conb_1 _207_ (.HI(uio_oe[3]));
 sky130_fd_sc_hd__conb_1 _208_ (.HI(uio_oe[4]));
 sky130_fd_sc_hd__conb_1 _209_ (.HI(uio_oe[5]));
 sky130_fd_sc_hd__conb_1 _210_ (.HI(uio_oe[6]));
 sky130_fd_sc_hd__conb_1 _211_ (.HI(uio_oe[7]));
 inverter_macro u_inverter (.A(ui_in[0]),
    .Y(inverted));
endmodule
