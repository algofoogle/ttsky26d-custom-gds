module tt_um_algofoogle_hello_world (clk,
    ena,
    k0,
    k1,
    k2,
    k3,
    k4,
    rst_n,
    ui_in,
    uio_in,
    uio_oe,
    uio_out,
    uo_out);
 input clk;
 input ena;
 output k0;
 output k1;
 output k2;
 output k3;
 output k4;
 input rst_n;
 input [7:0] ui_in;
 input [7:0] uio_in;
 output [7:0] uio_oe;
 output [7:0] uio_out;
 output [7:0] uo_out;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire \counter[10] ;
 wire \counter[11] ;
 wire \counter[12] ;
 wire \counter[13] ;
 wire \counter[14] ;
 wire \counter[15] ;
 wire \counter[5] ;
 wire \counter[6] ;
 wire \counter[7] ;
 wire \counter[8] ;
 wire \counter[9] ;
 wire inverted;

 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_2_Left_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_2_Right_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_2_Left_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_2_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_2_Left_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_2_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_1_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_1_Right_88 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_2_Left_79 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_2_Right_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_1_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_1_Right_89 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_2_Left_80 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_2_Right_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_1_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_1_Right_90 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_2_Left_81 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_2_Right_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_1_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_1_Right_91 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_2_Left_82 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_2_Right_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_1_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_1_Right_92 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_2_Left_83 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_2_Right_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_1_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_1_Right_93 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_2_1_Left_78 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_2_1_Right_113 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_2_2_Left_103 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_2_2_Right_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_1_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_1_Right_94 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_2_1_Left_84 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_2_1_Right_114 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_2_2_Left_104 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_2_2_Right_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_1_Left_67 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_1_Right_95 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_2_1_Left_85 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_2_1_Right_115 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_2_2_Left_105 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_2_2_Right_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_1_Left_68 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_1_Right_96 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_2_1_Left_86 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_2_1_Right_116 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_2_2_Left_106 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_2_2_Right_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_2_Left_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_2_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_1_Left_69 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_1_Right_97 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_2_1_Left_87 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_2_1_Right_117 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_2_2_Left_107 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_2_2_Right_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_1_Left_70 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_1_Right_108 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_2_Left_98 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_2_Right_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_1_Left_71 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_1_Right_109 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_2_Left_99 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_2_Right_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_1_Left_72 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_1_Right_110 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_2_Left_100 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_2_Right_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_1_Left_73 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_1_Right_111 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_2_Left_101 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_2_Right_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_1_Left_74 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_1_Right_112 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_2_Left_102 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_2_Right_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_75 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_76 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_77 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_2_Left_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_2_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_2_Left_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_2_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_2_Left_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_2_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_2_Left_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_2_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_2_Left_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_2_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_2_Left_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_2_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_2_Left_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_2_Right_19 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_304 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_305 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_306 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_307 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_308 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_309 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_310 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_311 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_2_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_2_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_2_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_2_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_2_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_2_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_2_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_2_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_1_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_1_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_2_312 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_1_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_1_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_1_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_2_313 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_2_314 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_1_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_1_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_2_315 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_1_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_1_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_1_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_2_316 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_2_317 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_1_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_1_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_2_318 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_2_319 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_2_320 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_1_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_1_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_1_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_2_1_276 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_1_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_1_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_1_241 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_1_242 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_1_243 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_2_1_321 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_1_244 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_1_245 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_2_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_2_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_2_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_2_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_1_246 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_1_247 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_1_248 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_2_1_322 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_249 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_250 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_251 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_252 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_253 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_254 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_255 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_256 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_257 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_258 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_259 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_260 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_261 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_262 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_1_263 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_1_264 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_1_265 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_1_266 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_267 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_268 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_269 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_270 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_271 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_1_272 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_1_273 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_1_274 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_1_275 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_277 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_278 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_279 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_280 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_281 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_282 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_283 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_284 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_285 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_286 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_287 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_288 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_289 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_290 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_291 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_292 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_293 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_294 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_295 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_296 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_297 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_298 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_299 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_300 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_301 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_302 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_303 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_2_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_2_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_2_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_2_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_2_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_2_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_2_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_2_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_2_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_2_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_2_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_2_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_2_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_2_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_2_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_2_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_2_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_2_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_2_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_2_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_2_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_2_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_2_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_2_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_2_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_2_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_2_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_2_153 ();
 sky130_fd_sc_hd__inv_1 _086_ (.A(k3),
    .Y(_056_));
 sky130_fd_sc_hd__nand2_1 _087_ (.A(k0),
    .B(ui_in[0]),
    .Y(_057_));
 sky130_fd_sc_hd__nor2_1 _088_ (.A(k1),
    .B(ui_in[1]),
    .Y(_058_));
 sky130_fd_sc_hd__nand2_1 _089_ (.A(k1),
    .B(ui_in[1]),
    .Y(_059_));
 sky130_fd_sc_hd__nor2b_1 _090_ (.A(_058_),
    .B_N(_059_),
    .Y(_060_));
 sky130_fd_sc_hd__xnor2_1 _091_ (.A(_057_),
    .B(_060_),
    .Y(uo_out[1]));
 sky130_fd_sc_hd__o21ai_0 _092_ (.A1(_057_),
    .A2(_058_),
    .B1(_059_),
    .Y(_061_));
 sky130_fd_sc_hd__xnor2_1 _093_ (.A(k2),
    .B(ui_in[2]),
    .Y(_062_));
 sky130_fd_sc_hd__xnor2_1 _094_ (.A(_061_),
    .B(_062_),
    .Y(uo_out[2]));
 sky130_fd_sc_hd__maj3_1 _095_ (.A(k2),
    .B(ui_in[2]),
    .C(_061_),
    .X(_063_));
 sky130_fd_sc_hd__xnor2_1 _096_ (.A(k3),
    .B(ui_in[3]),
    .Y(_064_));
 sky130_fd_sc_hd__xnor2_1 _097_ (.A(_063_),
    .B(_064_),
    .Y(uo_out[3]));
 sky130_fd_sc_hd__maj3_1 _098_ (.A(k3),
    .B(ui_in[3]),
    .C(_063_),
    .X(_065_));
 sky130_fd_sc_hd__xnor2_1 _099_ (.A(k4),
    .B(ui_in[4]),
    .Y(_066_));
 sky130_fd_sc_hd__xnor2_1 _100_ (.A(_065_),
    .B(_066_),
    .Y(uo_out[4]));
 sky130_fd_sc_hd__maj3_1 _101_ (.A(k4),
    .B(ui_in[4]),
    .C(_065_),
    .X(_067_));
 sky130_fd_sc_hd__xnor2_1 _102_ (.A(\counter[5] ),
    .B(ui_in[5]),
    .Y(_068_));
 sky130_fd_sc_hd__xnor2_1 _103_ (.A(_067_),
    .B(_068_),
    .Y(uo_out[5]));
 sky130_fd_sc_hd__maj3_1 _104_ (.A(\counter[5] ),
    .B(ui_in[5]),
    .C(_067_),
    .X(_069_));
 sky130_fd_sc_hd__xnor2_1 _105_ (.A(\counter[6] ),
    .B(ui_in[6]),
    .Y(_070_));
 sky130_fd_sc_hd__xnor2_1 _106_ (.A(_069_),
    .B(_070_),
    .Y(uo_out[6]));
 sky130_fd_sc_hd__maj3_1 _107_ (.A(\counter[6] ),
    .B(ui_in[6]),
    .C(_069_),
    .X(_071_));
 sky130_fd_sc_hd__and2_0 _108_ (.A(\counter[7] ),
    .B(ui_in[7]),
    .X(_072_));
 sky130_fd_sc_hd__or2_0 _109_ (.A(\counter[7] ),
    .B(ui_in[7]),
    .X(_073_));
 sky130_fd_sc_hd__nand2b_1 _110_ (.A_N(_072_),
    .B(_073_),
    .Y(_074_));
 sky130_fd_sc_hd__xnor2_1 _111_ (.A(_071_),
    .B(_074_),
    .Y(uo_out[7]));
 sky130_fd_sc_hd__xnor2_1 _112_ (.A(\counter[8] ),
    .B(inverted),
    .Y(_075_));
 sky130_fd_sc_hd__inv_1 _113_ (.A(_075_),
    .Y(_076_));
 sky130_fd_sc_hd__o21a_1 _114_ (.A1(_071_),
    .A2(_072_),
    .B1(_073_),
    .X(_077_));
 sky130_fd_sc_hd__xnor2_1 _115_ (.A(_075_),
    .B(_077_),
    .Y(uio_out[0]));
 sky130_fd_sc_hd__xor2_1 _116_ (.A(inverted),
    .B(\counter[9] ),
    .X(_078_));
 sky130_fd_sc_hd__maj3_1 _117_ (.A(\counter[8] ),
    .B(inverted),
    .C(_077_),
    .X(_079_));
 sky130_fd_sc_hd__xor2_1 _118_ (.A(_078_),
    .B(_079_),
    .X(uio_out[1]));
 sky130_fd_sc_hd__xor2_1 _119_ (.A(inverted),
    .B(\counter[10] ),
    .X(_080_));
 sky130_fd_sc_hd__o2111ai_1 _120_ (.A1(_071_),
    .A2(_072_),
    .B1(_073_),
    .C1(_076_),
    .D1(_078_),
    .Y(_081_));
 sky130_fd_sc_hd__o21ai_0 _121_ (.A1(\counter[8] ),
    .A2(\counter[9] ),
    .B1(inverted),
    .Y(_082_));
 sky130_fd_sc_hd__nand2_1 _122_ (.A(_081_),
    .B(_082_),
    .Y(_083_));
 sky130_fd_sc_hd__xor2_1 _123_ (.A(_080_),
    .B(_083_),
    .X(uio_out[2]));
 sky130_fd_sc_hd__xor2_1 _124_ (.A(inverted),
    .B(\counter[11] ),
    .X(_084_));
 sky130_fd_sc_hd__maj3_1 _125_ (.A(inverted),
    .B(\counter[10] ),
    .C(_083_),
    .X(_085_));
 sky130_fd_sc_hd__xor2_1 _126_ (.A(_084_),
    .B(_085_),
    .X(uio_out[3]));
 sky130_fd_sc_hd__nand2_1 _127_ (.A(_080_),
    .B(_084_),
    .Y(_016_));
 sky130_fd_sc_hd__o21ai_0 _128_ (.A1(\counter[10] ),
    .A2(\counter[11] ),
    .B1(inverted),
    .Y(_017_));
 sky130_fd_sc_hd__o211a_1 _129_ (.A1(_081_),
    .A2(_016_),
    .B1(_017_),
    .C1(_082_),
    .X(_018_));
 sky130_fd_sc_hd__nor2_1 _130_ (.A(inverted),
    .B(\counter[12] ),
    .Y(_019_));
 sky130_fd_sc_hd__nand2_1 _131_ (.A(inverted),
    .B(\counter[12] ),
    .Y(_020_));
 sky130_fd_sc_hd__nor2b_1 _132_ (.A(_019_),
    .B_N(_020_),
    .Y(_021_));
 sky130_fd_sc_hd__xnor2_1 _133_ (.A(_018_),
    .B(_021_),
    .Y(uio_out[4]));
 sky130_fd_sc_hd__o21a_1 _134_ (.A1(_018_),
    .A2(_019_),
    .B1(_020_),
    .X(_022_));
 sky130_fd_sc_hd__nand2_1 _135_ (.A(inverted),
    .B(\counter[13] ),
    .Y(_023_));
 sky130_fd_sc_hd__nor2_1 _136_ (.A(inverted),
    .B(\counter[13] ),
    .Y(_024_));
 sky130_fd_sc_hd__xor2_1 _137_ (.A(inverted),
    .B(\counter[13] ),
    .X(_025_));
 sky130_fd_sc_hd__xnor2_1 _138_ (.A(_022_),
    .B(_025_),
    .Y(uio_out[5]));
 sky130_fd_sc_hd__o21ai_0 _139_ (.A1(_022_),
    .A2(_024_),
    .B1(_023_),
    .Y(_026_));
 sky130_fd_sc_hd__xnor2_1 _140_ (.A(inverted),
    .B(\counter[14] ),
    .Y(_027_));
 sky130_fd_sc_hd__xnor2_1 _141_ (.A(_026_),
    .B(_027_),
    .Y(uio_out[6]));
 sky130_fd_sc_hd__nor4bb_1 _142_ (.A(\counter[13] ),
    .B(\counter[14] ),
    .C_N(_022_),
    .D_N(inverted),
    .Y(_028_));
 sky130_fd_sc_hd__nor4b_1 _143_ (.A(inverted),
    .B(_022_),
    .C(_024_),
    .D_N(\counter[14] ),
    .Y(_029_));
 sky130_fd_sc_hd__nor2_1 _144_ (.A(_028_),
    .B(_029_),
    .Y(_030_));
 sky130_fd_sc_hd__xnor2_1 _145_ (.A(\counter[15] ),
    .B(_030_),
    .Y(uio_out[7]));
 sky130_fd_sc_hd__xor2_1 _146_ (.A(k0),
    .B(ui_in[0]),
    .X(uo_out[0]));
 sky130_fd_sc_hd__nand3_1 _147_ (.A(k0),
    .B(k1),
    .C(k2),
    .Y(_031_));
 sky130_fd_sc_hd__nor2_1 _148_ (.A(_056_),
    .B(_031_),
    .Y(_032_));
 sky130_fd_sc_hd__and3_1 _149_ (.A(k4),
    .B(\counter[5] ),
    .C(_032_),
    .X(_033_));
 sky130_fd_sc_hd__and3_1 _150_ (.A(\counter[6] ),
    .B(\counter[7] ),
    .C(_033_),
    .X(_034_));
 sky130_fd_sc_hd__and2_0 _151_ (.A(\counter[8] ),
    .B(_034_),
    .X(_035_));
 sky130_fd_sc_hd__and3_1 _152_ (.A(\counter[9] ),
    .B(\counter[10] ),
    .C(_035_),
    .X(_036_));
 sky130_fd_sc_hd__and2_0 _153_ (.A(\counter[11] ),
    .B(_036_),
    .X(_037_));
 sky130_fd_sc_hd__and3_1 _154_ (.A(\counter[12] ),
    .B(\counter[13] ),
    .C(_037_),
    .X(_038_));
 sky130_fd_sc_hd__and2_0 _155_ (.A(\counter[14] ),
    .B(_038_),
    .X(_039_));
 sky130_fd_sc_hd__o21ai_0 _156_ (.A1(\counter[14] ),
    .A2(_038_),
    .B1(rst_n),
    .Y(_040_));
 sky130_fd_sc_hd__nor2_1 _157_ (.A(_039_),
    .B(_040_),
    .Y(_000_));
 sky130_fd_sc_hd__o21ai_0 _158_ (.A1(\counter[15] ),
    .A2(_039_),
    .B1(rst_n),
    .Y(_041_));
 sky130_fd_sc_hd__a21oi_1 _159_ (.A1(\counter[15] ),
    .A2(_039_),
    .B1(_041_),
    .Y(_001_));
 sky130_fd_sc_hd__nor2b_1 _160_ (.A(k0),
    .B_N(rst_n),
    .Y(_002_));
 sky130_fd_sc_hd__o21ai_0 _161_ (.A1(k0),
    .A2(k1),
    .B1(rst_n),
    .Y(_042_));
 sky130_fd_sc_hd__a21oi_1 _162_ (.A1(k0),
    .A2(k1),
    .B1(_042_),
    .Y(_003_));
 sky130_fd_sc_hd__a21oi_1 _163_ (.A1(k0),
    .A2(k1),
    .B1(k2),
    .Y(_043_));
 sky130_fd_sc_hd__nand2_1 _164_ (.A(rst_n),
    .B(_031_),
    .Y(_044_));
 sky130_fd_sc_hd__nor2_1 _165_ (.A(_043_),
    .B(_044_),
    .Y(_004_));
 sky130_fd_sc_hd__a31oi_1 _166_ (.A1(k0),
    .A2(k1),
    .A3(k2),
    .B1(k3),
    .Y(_045_));
 sky130_fd_sc_hd__nor3b_1 _167_ (.A(_032_),
    .B(_045_),
    .C_N(rst_n),
    .Y(_005_));
 sky130_fd_sc_hd__o21ai_0 _168_ (.A1(k4),
    .A2(_032_),
    .B1(rst_n),
    .Y(_046_));
 sky130_fd_sc_hd__a21oi_1 _169_ (.A1(k4),
    .A2(_032_),
    .B1(_046_),
    .Y(_006_));
 sky130_fd_sc_hd__a21oi_1 _170_ (.A1(k4),
    .A2(_032_),
    .B1(\counter[5] ),
    .Y(_047_));
 sky130_fd_sc_hd__nor3b_1 _171_ (.A(_033_),
    .B(_047_),
    .C_N(rst_n),
    .Y(_007_));
 sky130_fd_sc_hd__o21ai_0 _172_ (.A1(\counter[6] ),
    .A2(_033_),
    .B1(rst_n),
    .Y(_048_));
 sky130_fd_sc_hd__a21oi_1 _173_ (.A1(\counter[6] ),
    .A2(_033_),
    .B1(_048_),
    .Y(_008_));
 sky130_fd_sc_hd__a21oi_1 _174_ (.A1(\counter[6] ),
    .A2(_033_),
    .B1(\counter[7] ),
    .Y(_049_));
 sky130_fd_sc_hd__nor3b_1 _175_ (.A(_034_),
    .B(_049_),
    .C_N(rst_n),
    .Y(_009_));
 sky130_fd_sc_hd__o21ai_0 _176_ (.A1(\counter[8] ),
    .A2(_034_),
    .B1(rst_n),
    .Y(_050_));
 sky130_fd_sc_hd__nor2_1 _177_ (.A(_035_),
    .B(_050_),
    .Y(_010_));
 sky130_fd_sc_hd__o21ai_0 _178_ (.A1(\counter[9] ),
    .A2(_035_),
    .B1(rst_n),
    .Y(_051_));
 sky130_fd_sc_hd__a21oi_1 _179_ (.A1(\counter[9] ),
    .A2(_035_),
    .B1(_051_),
    .Y(_011_));
 sky130_fd_sc_hd__a21oi_1 _180_ (.A1(\counter[9] ),
    .A2(_035_),
    .B1(\counter[10] ),
    .Y(_052_));
 sky130_fd_sc_hd__nor3b_1 _181_ (.A(_036_),
    .B(_052_),
    .C_N(rst_n),
    .Y(_012_));
 sky130_fd_sc_hd__o21ai_0 _182_ (.A1(\counter[11] ),
    .A2(_036_),
    .B1(rst_n),
    .Y(_053_));
 sky130_fd_sc_hd__nor2_1 _183_ (.A(_037_),
    .B(_053_),
    .Y(_013_));
 sky130_fd_sc_hd__o21ai_0 _184_ (.A1(\counter[12] ),
    .A2(_037_),
    .B1(rst_n),
    .Y(_054_));
 sky130_fd_sc_hd__a21oi_1 _185_ (.A1(\counter[12] ),
    .A2(_037_),
    .B1(_054_),
    .Y(_014_));
 sky130_fd_sc_hd__a21oi_1 _186_ (.A1(\counter[12] ),
    .A2(_037_),
    .B1(\counter[13] ),
    .Y(_055_));
 sky130_fd_sc_hd__nor3b_1 _187_ (.A(_038_),
    .B(_055_),
    .C_N(rst_n),
    .Y(_015_));
 sky130_fd_sc_hd__dfxtp_1 _188_ (.CLK(clk),
    .D(_008_),
    .Q(\counter[6] ));
 sky130_fd_sc_hd__dfxtp_1 _189_ (.CLK(clk),
    .D(_009_),
    .Q(\counter[7] ));
 sky130_fd_sc_hd__dfxtp_1 _190_ (.CLK(clk),
    .D(_010_),
    .Q(\counter[8] ));
 sky130_fd_sc_hd__dfxtp_1 _191_ (.CLK(clk),
    .D(_011_),
    .Q(\counter[9] ));
 sky130_fd_sc_hd__dfxtp_1 _192_ (.CLK(clk),
    .D(_012_),
    .Q(\counter[10] ));
 sky130_fd_sc_hd__dfxtp_1 _193_ (.CLK(clk),
    .D(_013_),
    .Q(\counter[11] ));
 sky130_fd_sc_hd__dfxtp_1 _194_ (.CLK(clk),
    .D(_014_),
    .Q(\counter[12] ));
 sky130_fd_sc_hd__dfxtp_1 _195_ (.CLK(clk),
    .D(_015_),
    .Q(\counter[13] ));
 sky130_fd_sc_hd__dfxtp_1 _196_ (.CLK(clk),
    .D(_000_),
    .Q(\counter[14] ));
 sky130_fd_sc_hd__dfxtp_1 _197_ (.CLK(clk),
    .D(_001_),
    .Q(\counter[15] ));
 sky130_fd_sc_hd__dfxtp_1 _198_ (.CLK(clk),
    .D(_002_),
    .Q(k0));
 sky130_fd_sc_hd__dfxtp_1 _199_ (.CLK(clk),
    .D(_003_),
    .Q(k1));
 sky130_fd_sc_hd__dfxtp_1 _200_ (.CLK(clk),
    .D(_004_),
    .Q(k2));
 sky130_fd_sc_hd__dfxtp_1 _201_ (.CLK(clk),
    .D(_005_),
    .Q(k3));
 sky130_fd_sc_hd__dfxtp_1 _202_ (.CLK(clk),
    .D(_006_),
    .Q(k4));
 sky130_fd_sc_hd__dfxtp_1 _203_ (.CLK(clk),
    .D(_007_),
    .Q(\counter[5] ));
 sky130_fd_sc_hd__conb_1 _204_ (.HI(uio_oe[0]));
 sky130_fd_sc_hd__conb_1 _205_ (.HI(uio_oe[1]));
 sky130_fd_sc_hd__conb_1 _206_ (.HI(uio_oe[2]));
 sky130_fd_sc_hd__conb_1 _207_ (.HI(uio_oe[3]));
 sky130_fd_sc_hd__conb_1 _208_ (.HI(uio_oe[4]));
 sky130_fd_sc_hd__conb_1 _209_ (.HI(uio_oe[5]));
 sky130_fd_sc_hd__conb_1 _210_ (.HI(uio_oe[6]));
 sky130_fd_sc_hd__conb_1 _211_ (.HI(uio_oe[7]));
 inverter_macro u_inverter (.A(ui_in[0]),
    .Y(inverted));
endmodule
