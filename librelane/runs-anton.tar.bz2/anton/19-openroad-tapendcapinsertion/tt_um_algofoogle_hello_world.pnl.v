module tt_um_algofoogle_hello_world (clk,
    ena,
    k0,
    k1,
    k2,
    k3,
    k4,
    rst_n,
    ui_in,
    uio_in,
    uio_oe,
    uio_out,
    uo_out);
 input clk;
 input ena;
 output k0;
 output k1;
 output k2;
 output k3;
 output k4;
 input rst_n;
 input [7:0] ui_in;
 input [7:0] uio_in;
 output [7:0] uio_oe;
 output [7:0] uio_out;
 output [7:0] uo_out;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire \counter[10] ;
 wire \counter[11] ;
 wire \counter[12] ;
 wire \counter[13] ;
 wire \counter[14] ;
 wire \counter[15] ;
 wire \counter[5] ;
 wire \counter[6] ;
 wire \counter[7] ;
 wire \counter[8] ;
 wire \counter[9] ;
 wire inverted;
 wire VDPWR;
 wire VGND;

 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_2_Left_10 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_2_Right_34 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_2_Left_9 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_2_Right_20 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_51 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_21 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_52 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_22 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_53 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_23 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_54 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_24 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_55 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_25 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_56 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_26 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_57 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_27 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_58 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_28 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_59 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_29 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_2_Left_0 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_2_Right_11 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_60 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_30 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_1_Left_50 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_1_Right_88 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_2_Left_79 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_2_Right_35 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_1_Left_61 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_1_Right_89 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_2_Left_80 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_2_Right_36 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_1_Left_62 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_1_Right_90 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_2_Left_81 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_2_Right_37 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_1_Left_63 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_1_Right_91 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_2_Left_82 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_2_Right_38 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_1_Left_64 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_1_Right_92 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_2_Left_83 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_2_Right_39 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_1_Left_65 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_1_Right_93 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_2_1_Left_78 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_2_1_Right_113 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_2_2_Left_103 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_2_2_Right_45 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_1_Left_66 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_1_Right_94 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_2_1_Left_84 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_2_1_Right_114 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_2_2_Left_104 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_2_2_Right_46 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_1_Left_67 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_1_Right_95 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_2_1_Left_85 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_2_1_Right_115 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_2_2_Left_105 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_2_2_Right_47 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_1_Left_68 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_1_Right_96 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_2_1_Left_86 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_2_1_Right_116 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_2_2_Left_106 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_2_2_Right_48 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_2_Left_1 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_2_Right_12 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_1_Left_69 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_1_Right_97 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_2_1_Left_87 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_2_1_Right_117 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_2_2_Left_107 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_2_2_Right_49 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_1_Left_70 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_1_Right_108 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_2_Left_98 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_2_Right_40 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_1_Left_71 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_1_Right_109 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_2_Left_99 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_2_Right_41 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_1_Left_72 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_1_Right_110 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_2_Left_100 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_2_Right_42 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_1_Left_73 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_1_Right_111 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_2_Left_101 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_2_Right_43 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_1_Left_74 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_1_Right_112 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_2_Left_102 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_2_Right_44 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_75 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_31 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_76 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_32 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_77 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_33 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_2_Left_2 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_2_Right_13 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_2_Left_3 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_2_Right_14 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_2_Left_4 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_2_Right_15 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_2_Left_5 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_2_Right_16 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_2_Left_6 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_2_Right_17 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_2_Left_7 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_2_Right_18 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_2_Left_8 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_2_Right_19 (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_304 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_305 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_306 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_307 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_308 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_309 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_310 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2_311 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_2_154 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_2_155 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_2_156 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_2_157 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_160 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_161 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_162 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_163 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_164 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_165 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_166 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_167 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_168 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_169 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_170 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_171 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_172 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_173 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_174 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_175 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_176 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_177 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_178 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_179 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_180 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_181 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_182 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_183 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_184 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_185 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_186 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_187 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_188 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_189 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_190 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_191 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_192 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_193 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_194 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_195 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_196 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_197 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_198 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_199 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_200 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_201 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_202 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_203 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_204 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_205 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_206 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_207 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_208 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_209 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_210 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_211 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_212 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_213 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_214 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_2_118 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_2_119 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_2_120 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_2_121 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_215 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_216 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_217 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_218 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_219 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_220 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_221 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_222 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_223 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_224 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_225 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_1_158 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_1_159 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_2_312 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_1_226 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_1_227 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_1_228 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_2_313 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_2_314 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_1_229 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_1_230 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_2_315 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_1_231 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_1_232 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_1_233 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_2_316 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_2_317 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_1_234 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_1_235 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_2_318 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_2_319 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_2_320 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_1_236 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_1_237 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_1_238 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_2_1_276 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_1_239 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_1_240 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_1_241 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_1_242 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_1_243 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_2_1_321 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_1_244 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_1_245 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_2_122 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_2_123 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_2_124 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_2_125 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_1_246 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_1_247 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_1_248 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_2_1_322 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_249 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_250 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_251 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_252 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_253 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_254 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_255 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_256 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_1_257 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_258 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_259 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_260 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_261 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_1_262 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_1_263 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_1_264 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_1_265 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_1_266 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_267 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_268 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_269 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_270 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_1_271 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_1_272 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_1_273 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_1_274 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_1_275 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_277 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_278 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_279 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_280 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_281 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_282 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_283 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_284 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_285 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_286 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_287 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_288 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_289 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_290 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_291 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_292 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_293 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_294 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_295 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_296 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_297 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_298 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_299 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_300 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_301 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_302 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_303 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_2_126 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_2_127 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_2_128 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_2_129 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_2_130 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_2_131 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_2_132 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_2_133 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_2_134 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_2_135 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_2_136 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_2_137 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_2_138 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_2_139 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_2_140 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_2_141 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_2_142 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_2_143 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_2_144 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_2_145 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_2_146 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_2_147 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_2_148 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_2_149 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_2_150 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_2_151 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_2_152 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_2_153 (.VGND(VGND),
    .VPWR(VDPWR));
 sky130_fd_sc_hd__inv_1 _086_ (.A(k3),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_056_));
 sky130_fd_sc_hd__nand2_1 _087_ (.A(k0),
    .B(ui_in[0]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_057_));
 sky130_fd_sc_hd__nor2_1 _088_ (.A(k1),
    .B(ui_in[1]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_058_));
 sky130_fd_sc_hd__nand2_1 _089_ (.A(k1),
    .B(ui_in[1]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_059_));
 sky130_fd_sc_hd__nor2b_1 _090_ (.A(_058_),
    .B_N(_059_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_060_));
 sky130_fd_sc_hd__xnor2_1 _091_ (.A(_057_),
    .B(_060_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uo_out[1]));
 sky130_fd_sc_hd__o21ai_0 _092_ (.A1(_057_),
    .A2(_058_),
    .B1(_059_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_061_));
 sky130_fd_sc_hd__xnor2_1 _093_ (.A(k2),
    .B(ui_in[2]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_062_));
 sky130_fd_sc_hd__xnor2_1 _094_ (.A(_061_),
    .B(_062_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uo_out[2]));
 sky130_fd_sc_hd__maj3_1 _095_ (.A(k2),
    .B(ui_in[2]),
    .C(_061_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_063_));
 sky130_fd_sc_hd__xnor2_1 _096_ (.A(k3),
    .B(ui_in[3]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_064_));
 sky130_fd_sc_hd__xnor2_1 _097_ (.A(_063_),
    .B(_064_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uo_out[3]));
 sky130_fd_sc_hd__maj3_1 _098_ (.A(k3),
    .B(ui_in[3]),
    .C(_063_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_065_));
 sky130_fd_sc_hd__xnor2_1 _099_ (.A(k4),
    .B(ui_in[4]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_066_));
 sky130_fd_sc_hd__xnor2_1 _100_ (.A(_065_),
    .B(_066_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uo_out[4]));
 sky130_fd_sc_hd__maj3_1 _101_ (.A(k4),
    .B(ui_in[4]),
    .C(_065_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_067_));
 sky130_fd_sc_hd__xnor2_1 _102_ (.A(\counter[5] ),
    .B(ui_in[5]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_068_));
 sky130_fd_sc_hd__xnor2_1 _103_ (.A(_067_),
    .B(_068_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uo_out[5]));
 sky130_fd_sc_hd__maj3_1 _104_ (.A(\counter[5] ),
    .B(ui_in[5]),
    .C(_067_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_069_));
 sky130_fd_sc_hd__xnor2_1 _105_ (.A(\counter[6] ),
    .B(ui_in[6]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_070_));
 sky130_fd_sc_hd__xnor2_1 _106_ (.A(_069_),
    .B(_070_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uo_out[6]));
 sky130_fd_sc_hd__maj3_1 _107_ (.A(\counter[6] ),
    .B(ui_in[6]),
    .C(_069_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_071_));
 sky130_fd_sc_hd__and2_0 _108_ (.A(\counter[7] ),
    .B(ui_in[7]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_072_));
 sky130_fd_sc_hd__or2_0 _109_ (.A(\counter[7] ),
    .B(ui_in[7]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_073_));
 sky130_fd_sc_hd__nand2b_1 _110_ (.A_N(_072_),
    .B(_073_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_074_));
 sky130_fd_sc_hd__xnor2_1 _111_ (.A(_071_),
    .B(_074_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uo_out[7]));
 sky130_fd_sc_hd__xnor2_1 _112_ (.A(\counter[8] ),
    .B(inverted),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_075_));
 sky130_fd_sc_hd__inv_1 _113_ (.A(_075_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_076_));
 sky130_fd_sc_hd__o21a_1 _114_ (.A1(_071_),
    .A2(_072_),
    .B1(_073_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_077_));
 sky130_fd_sc_hd__xnor2_1 _115_ (.A(_075_),
    .B(_077_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uio_out[0]));
 sky130_fd_sc_hd__xor2_1 _116_ (.A(inverted),
    .B(\counter[9] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_078_));
 sky130_fd_sc_hd__maj3_1 _117_ (.A(\counter[8] ),
    .B(inverted),
    .C(_077_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_079_));
 sky130_fd_sc_hd__xor2_1 _118_ (.A(_078_),
    .B(_079_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(uio_out[1]));
 sky130_fd_sc_hd__xor2_1 _119_ (.A(inverted),
    .B(\counter[10] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_080_));
 sky130_fd_sc_hd__o2111ai_1 _120_ (.A1(_071_),
    .A2(_072_),
    .B1(_073_),
    .C1(_076_),
    .D1(_078_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_081_));
 sky130_fd_sc_hd__o21ai_0 _121_ (.A1(\counter[8] ),
    .A2(\counter[9] ),
    .B1(inverted),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_082_));
 sky130_fd_sc_hd__nand2_1 _122_ (.A(_081_),
    .B(_082_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_083_));
 sky130_fd_sc_hd__xor2_1 _123_ (.A(_080_),
    .B(_083_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(uio_out[2]));
 sky130_fd_sc_hd__xor2_1 _124_ (.A(inverted),
    .B(\counter[11] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_084_));
 sky130_fd_sc_hd__maj3_1 _125_ (.A(inverted),
    .B(\counter[10] ),
    .C(_083_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_085_));
 sky130_fd_sc_hd__xor2_1 _126_ (.A(_084_),
    .B(_085_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(uio_out[3]));
 sky130_fd_sc_hd__nand2_1 _127_ (.A(_080_),
    .B(_084_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_016_));
 sky130_fd_sc_hd__o21ai_0 _128_ (.A1(\counter[10] ),
    .A2(\counter[11] ),
    .B1(inverted),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_017_));
 sky130_fd_sc_hd__o211a_1 _129_ (.A1(_081_),
    .A2(_016_),
    .B1(_017_),
    .C1(_082_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_018_));
 sky130_fd_sc_hd__nor2_1 _130_ (.A(inverted),
    .B(\counter[12] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_019_));
 sky130_fd_sc_hd__nand2_1 _131_ (.A(inverted),
    .B(\counter[12] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_020_));
 sky130_fd_sc_hd__nor2b_1 _132_ (.A(_019_),
    .B_N(_020_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_021_));
 sky130_fd_sc_hd__xnor2_1 _133_ (.A(_018_),
    .B(_021_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uio_out[4]));
 sky130_fd_sc_hd__o21a_1 _134_ (.A1(_018_),
    .A2(_019_),
    .B1(_020_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_022_));
 sky130_fd_sc_hd__nand2_1 _135_ (.A(inverted),
    .B(\counter[13] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_023_));
 sky130_fd_sc_hd__nor2_1 _136_ (.A(inverted),
    .B(\counter[13] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_024_));
 sky130_fd_sc_hd__xor2_1 _137_ (.A(inverted),
    .B(\counter[13] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_025_));
 sky130_fd_sc_hd__xnor2_1 _138_ (.A(_022_),
    .B(_025_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uio_out[5]));
 sky130_fd_sc_hd__o21ai_0 _139_ (.A1(_022_),
    .A2(_024_),
    .B1(_023_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_026_));
 sky130_fd_sc_hd__xnor2_1 _140_ (.A(inverted),
    .B(\counter[14] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_027_));
 sky130_fd_sc_hd__xnor2_1 _141_ (.A(_026_),
    .B(_027_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uio_out[6]));
 sky130_fd_sc_hd__nor4bb_1 _142_ (.A(\counter[13] ),
    .B(\counter[14] ),
    .C_N(_022_),
    .D_N(inverted),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_028_));
 sky130_fd_sc_hd__nor4b_1 _143_ (.A(inverted),
    .B(_022_),
    .C(_024_),
    .D_N(\counter[14] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_029_));
 sky130_fd_sc_hd__nor2_1 _144_ (.A(_028_),
    .B(_029_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_030_));
 sky130_fd_sc_hd__xnor2_1 _145_ (.A(\counter[15] ),
    .B(_030_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(uio_out[7]));
 sky130_fd_sc_hd__xor2_1 _146_ (.A(k0),
    .B(ui_in[0]),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(uo_out[0]));
 sky130_fd_sc_hd__nand3_1 _147_ (.A(k0),
    .B(k1),
    .C(k2),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_031_));
 sky130_fd_sc_hd__nor2_1 _148_ (.A(_056_),
    .B(_031_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_032_));
 sky130_fd_sc_hd__and3_1 _149_ (.A(k4),
    .B(\counter[5] ),
    .C(_032_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_033_));
 sky130_fd_sc_hd__and3_1 _150_ (.A(\counter[6] ),
    .B(\counter[7] ),
    .C(_033_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_034_));
 sky130_fd_sc_hd__and2_0 _151_ (.A(\counter[8] ),
    .B(_034_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_035_));
 sky130_fd_sc_hd__and3_1 _152_ (.A(\counter[9] ),
    .B(\counter[10] ),
    .C(_035_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_036_));
 sky130_fd_sc_hd__and2_0 _153_ (.A(\counter[11] ),
    .B(_036_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_037_));
 sky130_fd_sc_hd__and3_1 _154_ (.A(\counter[12] ),
    .B(\counter[13] ),
    .C(_037_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_038_));
 sky130_fd_sc_hd__and2_0 _155_ (.A(\counter[14] ),
    .B(_038_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .X(_039_));
 sky130_fd_sc_hd__o21ai_0 _156_ (.A1(\counter[14] ),
    .A2(_038_),
    .B1(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_040_));
 sky130_fd_sc_hd__nor2_1 _157_ (.A(_039_),
    .B(_040_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_000_));
 sky130_fd_sc_hd__o21ai_0 _158_ (.A1(\counter[15] ),
    .A2(_039_),
    .B1(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_041_));
 sky130_fd_sc_hd__a21oi_1 _159_ (.A1(\counter[15] ),
    .A2(_039_),
    .B1(_041_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_001_));
 sky130_fd_sc_hd__nor2b_1 _160_ (.A(k0),
    .B_N(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_002_));
 sky130_fd_sc_hd__o21ai_0 _161_ (.A1(k0),
    .A2(k1),
    .B1(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_042_));
 sky130_fd_sc_hd__a21oi_1 _162_ (.A1(k0),
    .A2(k1),
    .B1(_042_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_003_));
 sky130_fd_sc_hd__a21oi_1 _163_ (.A1(k0),
    .A2(k1),
    .B1(k2),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_043_));
 sky130_fd_sc_hd__nand2_1 _164_ (.A(rst_n),
    .B(_031_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_044_));
 sky130_fd_sc_hd__nor2_1 _165_ (.A(_043_),
    .B(_044_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_004_));
 sky130_fd_sc_hd__a31oi_1 _166_ (.A1(k0),
    .A2(k1),
    .A3(k2),
    .B1(k3),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_045_));
 sky130_fd_sc_hd__nor3b_1 _167_ (.A(_032_),
    .B(_045_),
    .C_N(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_005_));
 sky130_fd_sc_hd__o21ai_0 _168_ (.A1(k4),
    .A2(_032_),
    .B1(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_046_));
 sky130_fd_sc_hd__a21oi_1 _169_ (.A1(k4),
    .A2(_032_),
    .B1(_046_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_006_));
 sky130_fd_sc_hd__a21oi_1 _170_ (.A1(k4),
    .A2(_032_),
    .B1(\counter[5] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_047_));
 sky130_fd_sc_hd__nor3b_1 _171_ (.A(_033_),
    .B(_047_),
    .C_N(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_007_));
 sky130_fd_sc_hd__o21ai_0 _172_ (.A1(\counter[6] ),
    .A2(_033_),
    .B1(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_048_));
 sky130_fd_sc_hd__a21oi_1 _173_ (.A1(\counter[6] ),
    .A2(_033_),
    .B1(_048_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_008_));
 sky130_fd_sc_hd__a21oi_1 _174_ (.A1(\counter[6] ),
    .A2(_033_),
    .B1(\counter[7] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_049_));
 sky130_fd_sc_hd__nor3b_1 _175_ (.A(_034_),
    .B(_049_),
    .C_N(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_009_));
 sky130_fd_sc_hd__o21ai_0 _176_ (.A1(\counter[8] ),
    .A2(_034_),
    .B1(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_050_));
 sky130_fd_sc_hd__nor2_1 _177_ (.A(_035_),
    .B(_050_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_010_));
 sky130_fd_sc_hd__o21ai_0 _178_ (.A1(\counter[9] ),
    .A2(_035_),
    .B1(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_051_));
 sky130_fd_sc_hd__a21oi_1 _179_ (.A1(\counter[9] ),
    .A2(_035_),
    .B1(_051_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_011_));
 sky130_fd_sc_hd__a21oi_1 _180_ (.A1(\counter[9] ),
    .A2(_035_),
    .B1(\counter[10] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_052_));
 sky130_fd_sc_hd__nor3b_1 _181_ (.A(_036_),
    .B(_052_),
    .C_N(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_012_));
 sky130_fd_sc_hd__o21ai_0 _182_ (.A1(\counter[11] ),
    .A2(_036_),
    .B1(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_053_));
 sky130_fd_sc_hd__nor2_1 _183_ (.A(_037_),
    .B(_053_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_013_));
 sky130_fd_sc_hd__o21ai_0 _184_ (.A1(\counter[12] ),
    .A2(_037_),
    .B1(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_054_));
 sky130_fd_sc_hd__a21oi_1 _185_ (.A1(\counter[12] ),
    .A2(_037_),
    .B1(_054_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_014_));
 sky130_fd_sc_hd__a21oi_1 _186_ (.A1(\counter[12] ),
    .A2(_037_),
    .B1(\counter[13] ),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_055_));
 sky130_fd_sc_hd__nor3b_1 _187_ (.A(_038_),
    .B(_055_),
    .C_N(rst_n),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Y(_015_));
 sky130_fd_sc_hd__dfxtp_1 _188_ (.CLK(clk),
    .D(_008_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[6] ));
 sky130_fd_sc_hd__dfxtp_1 _189_ (.CLK(clk),
    .D(_009_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[7] ));
 sky130_fd_sc_hd__dfxtp_1 _190_ (.CLK(clk),
    .D(_010_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[8] ));
 sky130_fd_sc_hd__dfxtp_1 _191_ (.CLK(clk),
    .D(_011_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[9] ));
 sky130_fd_sc_hd__dfxtp_1 _192_ (.CLK(clk),
    .D(_012_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[10] ));
 sky130_fd_sc_hd__dfxtp_1 _193_ (.CLK(clk),
    .D(_013_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[11] ));
 sky130_fd_sc_hd__dfxtp_1 _194_ (.CLK(clk),
    .D(_014_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[12] ));
 sky130_fd_sc_hd__dfxtp_1 _195_ (.CLK(clk),
    .D(_015_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[13] ));
 sky130_fd_sc_hd__dfxtp_1 _196_ (.CLK(clk),
    .D(_000_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[14] ));
 sky130_fd_sc_hd__dfxtp_1 _197_ (.CLK(clk),
    .D(_001_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[15] ));
 sky130_fd_sc_hd__dfxtp_1 _198_ (.CLK(clk),
    .D(_002_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(k0));
 sky130_fd_sc_hd__dfxtp_1 _199_ (.CLK(clk),
    .D(_003_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(k1));
 sky130_fd_sc_hd__dfxtp_1 _200_ (.CLK(clk),
    .D(_004_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(k2));
 sky130_fd_sc_hd__dfxtp_1 _201_ (.CLK(clk),
    .D(_005_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(k3));
 sky130_fd_sc_hd__dfxtp_1 _202_ (.CLK(clk),
    .D(_006_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(k4));
 sky130_fd_sc_hd__dfxtp_1 _203_ (.CLK(clk),
    .D(_007_),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .Q(\counter[5] ));
 sky130_fd_sc_hd__conb_1 _204_ (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .HI(uio_oe[0]));
 sky130_fd_sc_hd__conb_1 _205_ (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .HI(uio_oe[1]));
 sky130_fd_sc_hd__conb_1 _206_ (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .HI(uio_oe[2]));
 sky130_fd_sc_hd__conb_1 _207_ (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .HI(uio_oe[3]));
 sky130_fd_sc_hd__conb_1 _208_ (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .HI(uio_oe[4]));
 sky130_fd_sc_hd__conb_1 _209_ (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .HI(uio_oe[5]));
 sky130_fd_sc_hd__conb_1 _210_ (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .HI(uio_oe[6]));
 sky130_fd_sc_hd__conb_1 _211_ (.VGND(VGND),
    .VNB(VGND),
    .VPB(VDPWR),
    .VPWR(VDPWR),
    .HI(uio_oe[7]));
 inverter_macro u_inverter (.A(ui_in[0]),
    .Y(inverted),
    .VCC(VDPWR),
    .VSS(VGND));
endmodule
